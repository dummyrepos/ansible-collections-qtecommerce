lamp
=========

This module installs lamp stack on centos and ubuntu flavors


Role Variables
--------------

apache_package: This variable sets the apache package name
php_packages: This variable sets the php packages to be installed 
info_page_path: This path sets the info.php file path 

Dependencies
------------


Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - lamp

License
-------

Apache

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).
